package gid.aid;

public class Demo {
	public int sum(int i,int j) {
		return i+j;
	}

}
